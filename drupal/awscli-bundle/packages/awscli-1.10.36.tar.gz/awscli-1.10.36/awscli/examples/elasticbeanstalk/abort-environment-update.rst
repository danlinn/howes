**To abort a deployment**

The following command aborts a running application version deployment for an environment named ``my-env``::

  aws elasticbeanstalk abort-environment-update --environment-name my-env
