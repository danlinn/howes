**To get information about a policy attached to an IAM role**

The following ``get-role-policy`` command gets information about the specified policy attached to the role named ``Test-Role``::

  aws iam get-role-policy --role-name Test-Role --policy-name ExamplePolicy

Output::

    {
      "RoleName": "Test-Role",
      "PolicyDocument": {
          "Statement": [
              {
                  "Action": [
                      "s3:ListBucket",
                      "s3:Put*",
                      "s3:Get*",
                      "s3:*MultipartUpload*"
                  ],
                  "Resource": "*",
                  "Effect": "Allow",
                  "Sid": "1"
              }
          ]
      }
      "PolicyName": "ExamplePolicy"
    }

For more information, see `Creating a Role`_ in the *Using IAM* guide.

.. _`Creating a Role`: http://docs.aws.amazon.com/IAM/latest/UserGuide/creating-role.html

